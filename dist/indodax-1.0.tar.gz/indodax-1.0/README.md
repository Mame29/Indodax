# indodax
Modul ini untuk trading di indodax

Jika anda suka dengan modul ini anda bisa donasi di:
DOGECOIN: D7rzpq91xmUVkER6E1ndfinRjRS4jvBkgV
LTC     : M9nQQZXwHQaoNStJrBcr6UfdCqx2RJHz5e
